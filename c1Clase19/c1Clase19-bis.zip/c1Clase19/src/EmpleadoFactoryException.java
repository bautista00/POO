public class EmpleadoFactoryException extends Exception{
    public EmpleadoFactoryException(String message) {
        super(message);
    }
}
