public class Persona {

    private String nombre;
    private String apellido;
    private Integer dni;
    private Integer edad;

    public Persona(String nombre, String apellido, Integer dni, Integer edad) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.edad = edad;
    }
}
